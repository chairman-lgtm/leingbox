# Leingbox Finance

第一版财务记账网站。

功能：
- UMO / MARS 登录
- 名字
- 总数
- 已扣价钱
- 剩余金额自动计算
- 添加、修改、删除项目
- 手机 / 电脑自适应
- 数据先保存在当前浏览器 localStorage

注意：
此版本适合先测试页面和流程。
正式财务使用建议下一步接 Supabase：
1. Supabase Auth 管理 UMO / MARS 密码
2. Supabase Database 云端同步记录
3. Vercel 部署
4. Shopify DNS 指向 leingbox.com
