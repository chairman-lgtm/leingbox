const $ = (id) => document.getElementById(id);

const state = {
  user: null,
  ledger: {
    name: "",
    total: 0,
    items: [],
    updatedAt: null
  }
};

function userKey(user){ return `leingbox_finance_${user}`; }
function passKey(user){ return `leingbox_pass_${user}`; }

async function sha256(text){
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,"0")).join("");
}

function money(n){
  const num = Number(n || 0);
  return `RM ${num.toLocaleString("en-MY",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
}

function nowText(){
  return new Date().toLocaleString("en-MY", {
    year:"numeric", month:"2-digit", day:"2-digit",
    hour:"2-digit", minute:"2-digit"
  });
}

function loadLedger(){
  const raw = localStorage.getItem(userKey(state.user));
  if(raw){
    try{ state.ledger = JSON.parse(raw); }catch(e){}
  } else {
    state.ledger = {name:"", total:0, items:[], updatedAt:null};
  }
}

function saveLedger(){
  state.ledger.updatedAt = nowText();
  localStorage.setItem(userKey(state.user), JSON.stringify(state.ledger));
  render();
}

function calculate(){
  const spent = state.ledger.items.reduce((s,i)=>s + Number(i.price || 0),0);
  const remaining = Number(state.ledger.total || 0) - spent;
  return {spent, remaining};
}

function render(){
  $("ledgerName").value = state.ledger.name || "";
  $("totalAmount").value = state.ledger.total || "";
  const {spent, remaining} = calculate();
  $("totalDisplay").textContent = money(state.ledger.total);
  $("spentDisplay").textContent = money(spent);
  $("remainingDisplay").textContent = money(remaining);
  $("itemCount").textContent = state.ledger.items.length;
  $("lastUpdated").textContent = state.ledger.updatedAt || "—";
  $("currentUser").textContent = state.user;

  const list = $("itemsList");
  list.innerHTML = "";
  $("emptyState").style.display = state.ledger.items.length ? "none" : "block";

  state.ledger.items.forEach((item,index)=>{
    const node = $("itemTemplate").content.firstElementChild.cloneNode(true);
    const name = node.querySelector(".item-name");
    const price = node.querySelector(".item-price");
    const del = node.querySelector(".delete-btn");

    name.value = item.name || "";
    price.value = item.price || "";

    name.addEventListener("input", ()=>{
      state.ledger.items[index].name = name.value;
      saveLedger();
    });
    price.addEventListener("input", ()=>{
      state.ledger.items[index].price = Number(price.value || 0);
      saveLedger();
    });
    del.addEventListener("click", ()=>{
      if(confirm("确定删除这个项目吗？")){
        state.ledger.items.splice(index,1);
        saveLedger();
      }
    });
    list.appendChild(node);
  });
}

async function login(){
  const user = $("loginUser").value;
  const pass = $("loginPassword").value.trim();
  const msg = $("loginMsg");
  msg.textContent = "";

  if(!pass){
    msg.textContent = "请输入密码。";
    return;
  }

  const stored = localStorage.getItem(passKey(user));
  const hashed = await sha256(pass);

  if(!stored){
    const ok = confirm(`${user} 还没有设置密码。\n是否把你刚输入的密码设为这个账号的测试密码？`);
    if(!ok) return;
    localStorage.setItem(passKey(user), hashed);
  } else if(stored !== hashed){
    msg.textContent = "密码不正确。";
    return;
  }

  state.user = user;
  sessionStorage.setItem("leingbox_user", user);
  loadLedger();
  $("loginView").classList.add("hidden");
  $("appView").classList.remove("hidden");
  $("loginPassword").value = "";
  render();
}

$("loginBtn").addEventListener("click", login);
$("loginPassword").addEventListener("keydown", e=>{ if(e.key==="Enter") login(); });

$("logoutBtn").addEventListener("click", ()=>{
  sessionStorage.removeItem("leingbox_user");
  state.user = null;
  $("appView").classList.add("hidden");
  $("loginView").classList.remove("hidden");
});

$("ledgerName").addEventListener("input", e=>{
  state.ledger.name = e.target.value;
  saveLedger();
});
$("totalAmount").addEventListener("input", e=>{
  state.ledger.total = Number(e.target.value || 0);
  saveLedger();
});

$("addItemBtn").addEventListener("click", ()=>{
  state.ledger.items.push({name:"",price:0});
  saveLedger();
  setTimeout(()=>{
    const inputs = document.querySelectorAll(".item-name");
    inputs[inputs.length-1]?.focus();
  },0);
});

(function init(){
  const existing = sessionStorage.getItem("leingbox_user");
  if(existing === "UMO" || existing === "MARS"){
    state.user = existing;
    loadLedger();
    $("loginView").classList.add("hidden");
    $("appView").classList.remove("hidden");
    render();
  }
})();